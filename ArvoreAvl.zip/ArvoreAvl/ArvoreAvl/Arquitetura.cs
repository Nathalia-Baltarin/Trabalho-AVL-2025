﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Arvore
{
    //a raiz pode ser nula, unico caso disso quando comeca a arvore 
    private No? _raiz;

    //construtor avl pois raiz é um atributo private
    public Arvore()
    {
        _raiz = null;
    }

    private int ObterAltura(No? no)
    {
        if (no == null)
            return 0;
        return no.Altura;
    }

   
    private void AtualizaAltura(No no)
    {
        no.Altura = 1 + Math.Max(ObterAltura(no.Esquerda), ObterAltura(no.Direita)); 
    }

    //aqui fazer a conta do fator de balanceamento
    private int FatorDeBalanceamento(No? no)
    {
        if (no == null)
            return 0;
        return ObterAltura(no.Esquerda) - ObterAltura(no.Direita);
    }

    // --- REMOÇÃO 
    public void Remover(int valor)
    {
        _raiz = RemoverRecursivo(_raiz, valor);
    }

    private No? RemoverRecursivo(No? noAtual, int valor)
    {
        if (noAtual == null)
            return null; // Valor não encontrado, retorna nulo

        // 1. Encontra o nó a ser removido
        if (valor < noAtual.Valor)
        {
            noAtual.Esquerda = RemoverRecursivo(noAtual.Esquerda, valor);
        }
        else if (valor > noAtual.Valor)
        {
            noAtual.Direita = RemoverRecursivo(noAtual.Direita, valor);
        }
        else // Nó encontrado, agora vamos removê-lo
        {
            // Caso 1: Nó com 0 ou 1 filho
            if (noAtual.Esquerda == null || noAtual.Direita == null)
            {
                No? temp = noAtual.Esquerda ?? noAtual.Direita;
                if (temp == null) // Sem filhos
                {
                    noAtual = null;
                }
                else // Um filho
                {
                    noAtual = temp; // Nó atual é substituído pelo seu único filho
                }
            }
            else 
            {
                // Encontra o sucessor em ordem (o menor valor na subárvore direita)
                No temp = ObterNoComMenorValor(noAtual.Direita);
                // Copia o valor do sucessor para o nó atual
                noAtual.Valor = temp.Valor;
                // Remove o nó sucessor da subárvore direita
                noAtual.Direita = RemoverRecursivo(noAtual.Direita, temp.Valor);
            }
        }

        // Se a árvore ficou vazia após a remoção (era o único nó), não há o que balancear.
        if (noAtual == null)
            return noAtual;

       
        AtualizaAltura(noAtual);

        int balanceamento = FatorDeBalanceamento(noAtual);

        // Caso Esquerda-Esquerda 
        if (balanceamento > 1 && FatorDeBalanceamento(noAtual.Esquerda) >= 0)
            return RodarDireita(noAtual);

        // Caso Esquerda-Direita 
        if (balanceamento > 1 && FatorDeBalanceamento(noAtual.Esquerda) < 0)
        {
            noAtual.Esquerda = RodarEsquerda(noAtual.Esquerda!);
            return RodarDireita(noAtual);
        }

        // Caso Direita-Direita 
        if (balanceamento < -1 && FatorDeBalanceamento(noAtual.Direita) <= 0)
            return RodarEsquerda(noAtual);

        // Caso Direita-Esquerda 
        if (balanceamento < -1 && FatorDeBalanceamento(noAtual.Direita) > 0)
        {
            noAtual.Direita = RodarDireita(noAtual.Direita!);
            return RodarEsquerda(noAtual);
        }

        return noAtual;
    }

    
    private No ObterNoComMenorValor(No no)
    {
        No atual = no;
        while (atual.Esquerda != null)
        {
            atual = atual.Esquerda;
        }
        return atual;
    }

    //alocacao e deslocacao dos valores e rotacao ()
    private No RodarDireita(No y)
    {
        No x = y.Esquerda!;
        No? SubDir = x.Direita;  // sub-arvore direita

        //faz a rotacao/troca
        x.Direita = y;
        y.Esquerda = SubDir;

        //atualiza as alturas, tem que ser nessa ordem pois é a ordem da troca
        AtualizaAltura(y);
        AtualizaAltura(x);

        //nova raiz
        return x;
    }

    private No RodarEsquerda(No x)
    {
       
       
        No y = x.Direita!;
        No? subEsq = y.Esquerda;

        //faz rotacao
        y.Esquerda = x;
        x.Direita = subEsq;

        AtualizaAltura(x);
        AtualizaAltura(y);

        //nova raiz 
        return y;
    }

    //colocar valores na arvore
    public void Inserir(int valor)
    {
        _raiz = InserirRecursivo(_raiz, valor); // rodar aqui e brincar com a raiz e o no atual.
    }

    private No? InserirRecursivo(No? noAtual, int valor)
    {
        if (noAtual == null)
        {
            //Console.WriteLine($"Inserindo {valor}");
            return new No(valor); // tipo malloc (pelo q entendi) ele cria espaco na memoria
        }

        if (valor < noAtual.Valor)
        {
            noAtual.Esquerda = InserirRecursivo(noAtual.Esquerda, valor);
        }
        else if (valor > noAtual.Valor)
        {
            noAtual.Direita = InserirRecursivo(noAtual.Direita, valor);
        }
        else
        {
            // Valor já existe, não faz nada
            return noAtual;
        }

        //apos add novo no tem que atualizar a altura
        AtualizaAltura(noAtual);
        int balanceamento = FatorDeBalanceamento(noAtual); 

        //Esquerda-esquerda
        if (balanceamento > 1 && valor < noAtual.Esquerda!.Valor)
        {
            return RodarDireita(noAtual);
        }

        //direita-direita
        if (balanceamento < -1 && valor > noAtual.Direita!.Valor)
        {
            return RodarEsquerda(noAtual);
        }

        //esquerda-direita desbalanceia para esquerda
        if (balanceamento > 1 && valor > noAtual.Esquerda!.Valor)
        {
            noAtual.Esquerda = RodarEsquerda(noAtual.Esquerda!);
            return RodarDireita(noAtual);
        }

        //direita-esquerda desbalanceia para direita
        if (balanceamento < -1 && valor < noAtual.Direita!.Valor)
        {
            noAtual.Direita = RodarDireita(noAtual.Direita!);
            return RodarEsquerda(noAtual);
        }

        return noAtual;
    }

    // BUSCA (B valor) 
    public void BuscarValor(int valor)
    {
        if (BuscarValorRecursivo(_raiz, valor))
        {
            Console.WriteLine("Valor encontrado");
        }
        else
        {
            Console.WriteLine("Valor nao encontrado");
        }
    }

    private bool BuscarValorRecursivo(No? noAtual, int valor)
    {
        if (noAtual == null)
            return false;

        if (valor == noAtual.Valor)
            return true;

        if (valor < noAtual.Valor)
            return BuscarValorRecursivo(noAtual.Esquerda, valor);
        else
            return BuscarValorRecursivo(noAtual.Direita, valor);
    }

// pre ordem
    public void ImprimirPreOrdem()
    {
        List<string> nos = new List<string>();
        ImprimirPreOrdemRecursivo(_raiz, nos);
        Console.WriteLine("Arvore em pre-ordem: " + string.Join(" ", nos));
    }

    private void ImprimirPreOrdemRecursivo(No? no, List<string> nos)
    {
        if (no != null)
        {
            nos.Add(no.Valor.ToString());
            ImprimirPreOrdemRecursivo(no.Esquerda, nos);
            ImprimirPreOrdemRecursivo(no.Direita, nos);
        }
    }

    // balanceamento
    public void ImprimirFatoresBalanceamento()
    {
        Console.WriteLine("Fatores de balanceamento:");
        ImprimirFatoresBalanceamentoRecursivo(_raiz);
    }

    private void ImprimirFatoresBalanceamentoRecursivo(No? no)
    {
        if (no != null)
        {
            Console.WriteLine($"No {no.Valor}: Fator de balanceamento {FatorDeBalanceamento(no)}");
            ImprimirFatoresBalanceamentoRecursivo(no.Esquerda);
            ImprimirFatoresBalanceamentoRecursivo(no.Direita);
        }
    }

    
    public void ImprimirAlturaArvore()
    {
        Console.WriteLine($"Altura da arvore: {ObterAltura(_raiz)}");
    }

    //imprimir na ordem 
    public void ImprimirEmOrdem()
    {
        Console.WriteLine("Percurso em ordem (valor ordenado):");
        ImprimirEmOrdemRecursivo(_raiz);
        Console.WriteLine("\n-----------");
    }

    private void ImprimirEmOrdemRecursivo(No? no)
    {
        if (no != null)
        {
            ImprimirEmOrdemRecursivo(no.Esquerda);
            Console.Write($"{no.Valor} (A:{no.Altura}, FB:{FatorDeBalanceamento(no)})  ");
            ImprimirEmOrdemRecursivo(no.Direita);
        }
    }

 
    public void ImprimirArvore()
    {
        Console.WriteLine("Estrutura da arvore:");
        ImprimirArvoreRecursivo(_raiz, "", false); 
        Console.WriteLine("-----------");
    }

    private void ImprimirArvoreRecursivo(No? no, string prefixo, bool ehFilhoEsquerdoDoPai)
    {
        // O caso base deve ser quando o nó é NULO.
        if (no == null)
        {
            return;
        }

        // Imprime a subárvore direita primeiro (para aparecer "em cima")
        ImprimirArvoreRecursivo(no.Direita, prefixo + (ehFilhoEsquerdoDoPai ? "│   " : "    "), false);

        // Imprime o nó atual
        Console.Write(prefixo);
        Console.Write(ehFilhoEsquerdoDoPai ? "├── " : "└── ");
        Console.WriteLine($"{no.Valor} (A:{no.Altura},FB:{FatorDeBalanceamento(no)})");

        // Imprime a subárvore esquerda (para aparecer "embaixo")
        ImprimirArvoreRecursivo(no.Esquerda, prefixo + (ehFilhoEsquerdoDoPai ? "    " : "│   "), true);
    }
}

public class No
{
    public int Valor { get; set; } //agora vamos resgatar os valores
    public No? Direita { get; set; } // para referenciar outro
    public No? Esquerda { get; set; } // para referenciar outro
    public int Altura { get; set; }

    //criacao de um primeiro no
    public No(int valor)
    {
        Valor = valor;
        Direita = null;
        Esquerda = null;
        Altura = 1; //quando cria o primeiro no ele tem altura 1
    }
}

