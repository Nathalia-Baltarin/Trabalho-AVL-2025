﻿using System;
using System.Collections.Generic; // Precisamos disso para a lista de comandos
using System.IO;



public class Program
{
    public static void Main(string[] args)
    {
        // --- LÓGICA DE ENTRADA MODIFICADA ---

        // 1. Instrui o usuário sobre como fornecer a entrada.
        Console.WriteLine("Cole ou digite seus comandos abaixo. Pressione Enter em uma linha vazia para processar.");
        Console.WriteLine("---------------------------------------------------------------------------------");

        List<string> linhasComando = new List<string>();
        string? linha;

        // 2. Lê linhas do console em um loop até encontrar uma linha vazia ou o fim da entrada.
        while (!string.IsNullOrEmpty(linha = Console.ReadLine()))
        {
            linhasComando.Add(linha);
        }

        

        // --- A LÓGICA DE PROCESSAMENTO PERMANECE A MESMA ---

        // 3. Cria a instância da sua árvore.
        Arvore arvoreAvl = new Arvore();

        // 4. Processa cada comando que foi coletado.
        foreach (string comandoLinha in linhasComando)
        {
            string linhaLimpa = comandoLinha.Trim();
            if (string.IsNullOrEmpty(linhaLimpa))
                continue;

            string[] partes = linhaLimpa.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string comando = partes[0].ToUpper();

            try
            {
                switch (comando)
                {
                    case "I":
                        int valorInserir = int.Parse(partes[1]);
                        arvoreAvl.Inserir(valorInserir);
                        break;
                    case "R":
                        int valorRemover = int.Parse(partes[1]);
                        arvoreAvl.Remover(valorRemover);
                        break;
                    case "B":
                        int valorBuscar = int.Parse(partes[1]);
                        arvoreAvl.BuscarValor(valorBuscar);
                        break;
                    case "P":
                        arvoreAvl.ImprimirPreOrdem();
                        break;
                    case "F":
                        arvoreAvl.ImprimirFatoresBalanceamento();
                        break;
                    case "H":
                        arvoreAvl.ImprimirAlturaArvore();
                        break;
                    default:
                        Console.WriteLine($"Comando invalido: '{comandoLinha}'");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao processar o comando '{comandoLinha}': {ex.Message}");
            }
        }
        Console.WriteLine("--- Fim da Execucao ---");
    }
}